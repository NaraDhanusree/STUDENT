package klu.model;

public class AdminLogin {

}
